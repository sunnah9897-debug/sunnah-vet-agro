package com.sunnahvetagro.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Alertes de Sunnah_Vet_Agro, sans Internet : rappels de soins et sauvegarde du dimanche.
 * Reçoit aussi le redémarrage du téléphone pour reprogrammer les alertes.
 */
public class AlarmReceiver extends BroadcastReceiver {

    static final String CHANNEL = "rappels";
    private static final String PREFS = "alertes";

    static void ensureChannel(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Rappels de la ferme",
                    NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Vaccins, déparasitages et sauvegarde de la semaine");
            nm.createNotificationChannel(ch);
        }
    }

    private static PendingIntent pending(Context c, int i, String title, String text) {
        Intent in = new Intent(c, AlarmReceiver.class);
        in.setAction("com.sunnahvetagro.app.ALERTE");
        in.putExtra("id", i);
        if (title != null) in.putExtra("title", title);
        if (text != null) in.putExtra("text", text);
        return PendingIntent.getBroadcast(c, 1000 + i, in,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void scheduleAll(Context c, String json) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        int old = sp.getInt("n", 0);
        for (int i = 0; i < old; i++) am.cancel(pending(c, i, null, null));
        int n = 0;
        try {
            JSONArray arr = new JSONArray(json);
            long now = System.currentTimeMillis();
            for (int i = 0; i < arr.length() && n < 40; i++) {
                JSONObject o = arr.getJSONObject(i);
                long at = o.getLong("at");
                if (at <= now) continue;
                am.set(AlarmManager.RTC_WAKEUP, at, pending(c, n, o.optString("title"), o.optString("text")));
                n++;
            }
        } catch (Exception ignored) {
        }
        sp.edit().putInt("n", n).putString("json", json).apply();
    }

    @Override
    public void onReceive(Context c, Intent intent) {
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            String json = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("json", null);
            if (json != null) scheduleAll(c, json);
            return;
        }
        ensureChannel(c);
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        String text = intent.getStringExtra("text");
        Notification nb = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(intent.getStringExtra("title"))
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            try {
                nm.notify(2000 + intent.getIntExtra("id", 0), nb);
            } catch (SecurityException ignored) {
            }
        }
    }
}
