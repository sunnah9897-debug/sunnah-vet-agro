plugins {
    id("com.android.application")
}

// Numéro de compilation fourni par GitHub Actions (1 en local).
val runNumber = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()

android {
    namespace = "com.sunnahvetagro.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sunnahvetagro.app"
        minSdk = 26
        targetSdk = 34
        versionCode = runNumber
        versionName = "1.0.$runNumber"
    }

    // Toujours la même clé : chaque nouvelle version s'installe par-dessus
    // l'ancienne SANS effacer les données de la ferme.
    signingConfigs {
        create("sva") {
            storeFile = rootProject.file("keystore/sunnahvetagro.jks")
            storePassword = "sunnahvetagro"
            keyAlias = "sunnahvetagro"
            keyPassword = "sunnahvetagro"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("sva")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("sva")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}
